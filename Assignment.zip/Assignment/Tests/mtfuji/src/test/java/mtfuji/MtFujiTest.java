package mtfuji;
import org.testng.*;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.google.gson.JsonParseException;
import com.google.gson.JsonParser;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.RestAssured;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.apache.http.HttpStatus;

public class MtFujiTest {
	/*
	 * Defining some variables like url, etc
	 */
	private String localUrl="http://localhost:8080/api/v1/users";
	@SuppressWarnings("deprecation")
	JsonParser parser = new JsonParser();
	ExcelDriver excelutil=new ExcelDriver("Data.xlsx");

	/*
	 *Doing delete all user before doing anything just for the sake of clean up but this should not be done at all
	 */
	@BeforeClass
	protected void clearData() {
		RestAssured.given().when().
		delete(localUrl);
	}

	/*
	 * Creating a dataprovider method to get data from excel in iterated way
	 */
	@DataProvider(name="getData")
	protected Object[][] getDataFromDataProvider(Method method) throws IOException{
		return this.excelutil.getAllMatchingTestCases("Users", method.getName());
	}


	/*
	 * FIRST TEST
	 * End to end test 
	 * 1. creating a user and then validating status code 201 and json response
	 * 2. using the id from the above response to do a Get call and validate 200 status code and json response
	 * 3. deleting the record using the id and checking for status 204 (here its 200)
	 * 
	 */

	@SuppressWarnings("deprecation")
	@Test(testName="testE2EPositive",enabled=true)
	public void testE2EPositive() throws JsonParseException, IOException {
		SoftAssert softAssert = new SoftAssert();
		String id="";

		Response postResponse=RestAssured.given().
				when().contentType(ContentType.JSON).
				body(new File(System.getProperty("user.dir")+"\\src\\test\\resources\\createuser.json")).
				post(localUrl);
		softAssert.assertEquals(postResponse.statusCode(),HttpStatus.SC_CREATED);

		if(postResponse.statusCode()!=HttpStatus.SC_CREATED) {
			Assert.fail("Failed to create user");
		}

		try {id=postResponse.body().jsonPath().getString("id");}catch(Exception e) {Assert.fail("Response body not json or json path incorrect");};


		softAssert.assertEquals(parser.parse(RestAssured.given().when().get(localUrl+"/"+id).body().asString()),
				parser.parse(FileUtils.readFileToString(new File(System.getProperty("user.dir")+"\\src\\test\\resources\\createuser.json")).replace("\"id\": 1", "\"id\": "+id)));

		RestAssured.given().when().
		delete(localUrl+"/"+id).
		then().statusCode(HttpStatus.SC_OK);//Should be SC_NO_CONTENT which is 204

		softAssert.assertAll();

	}


	/*
	 * SECOND TEST
	 * Is a combination of multiple negative scenario involving the data model in the create user method for status code 400
	 * TODO: validating the response messages
	 */

	@SuppressWarnings("deprecation")
	@Test(testName="testCreateUserNegativeData",dataProvider="getData",enabled=true)
	public void testCreateUserNegativeData(Map<Object,Object> map) throws JsonParseException, IOException {
		SoftAssert softAssert = new SoftAssert();
		String id="";

		Map<String,String> payload = new HashMap<String,String>();
		payload.put("birthDate", map.get("birthDate").toString());
		payload.put("firstName", map.get("firstName").toString());
		payload.put("lastName", map.get("lastName").toString());

		Response postResponse=RestAssured.given().
				when().contentType(ContentType.JSON).
				body(payload).
				post(localUrl);
		softAssert.assertEquals(postResponse.statusCode(),Math.round(Double.parseDouble(map.get("statusCode").toString())));
		Reporter.log(postResponse.statusCode()+" status code validated");

		if(postResponse.statusCode()==HttpStatus.SC_CREATED) {
			try {id=postResponse.body().jsonPath().getString("id");}catch(Exception e) {validationFail("Response body not json or json path incorrect");};
			RestAssured.given().when().
			delete(localUrl+"/"+id);
		}
		softAssert.assertAll();

	}

	private void validationFail(String message) {
		Reporter.log(message);
		Assert.fail(message);
	}
}
